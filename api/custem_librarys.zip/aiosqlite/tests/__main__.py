# Copyright 2018 John Reese
# Licensed under the MIT license

import unittest

if __name__ == "__main__":
    unittest.main(module="aiosqlite.tests", verbosity=2)
